import SceneMap from "./SceneMap";
import ScenePlayer from "./ScenePlayer";

export default class SceneManager
{
    private static _ins:SceneManager;
    public static get Ins():SceneManager{
        if (!this._ins)
            this._ins = new SceneManager();
        return this._ins;
    }

    private readonly _map:SceneMap;

    private _mainPlayer:ScenePlayer;
    private readonly _players:Array<ScenePlayer> = new Array<ScenePlayer>();

    constructor() {
        this._map = new SceneMap();
        Laya.stage.addChild(this._map.scenec.scene);
    }

    public init():void{
        this.addMain();
        Laya.stage.on(Laya.Event.RESIZE, this, this.onResize);
        Laya.stage.on(Laya.Event.MOUSE_DOWN, this, this.onDown);
        //Laya.stage.on(Laya.Event.KEY_DOWN, this, this.frameKeydown);
    }

    private addMain():void{
        this._mainPlayer = new ScenePlayer();
        this._mainPlayer.init();
        this._players.push(this._mainPlayer);
        this._map.addMiddle(this._mainPlayer);
    }

    private onResize():void{
        this._map.onResize();
    }

    private _a:Laya.Vector3 = new Laya.Vector3(0, -3, 0);
    // private _d:Laya.Vector3 = new Laya.Vector3(0, 3, 0);
    // private frameKeydown():void{
    //     if(Laya.KeyBoardManager.hasKeyDown(Laya.Keyboard.A)){
    //         this._mainPlayer.rot(this._a);
    //     }else if (Laya.KeyBoardManager.hasKeyDown(Laya.Keyboard.D)){
    //         this._mainPlayer.rot(this._d);
    //     }
    // }

    // ==============================
    // 点击移动

    private onDown():void{
        Laya.stage.once(Laya.Event.MOUSE_UP, this, this.onUp);
        Laya.stage.once(Laya.Event.MOUSE_OUT, this, this.onUp);
        Laya.timer.loop(1, this, this.frameMove);
    }
    private onUp():void{
        Laya.timer.clear(this, this.frameMove);
        this._mainPlayer.doIdle();
    }

    private mousePt:Laya.Point = new Laya.Point();
    private frameMove():void{
        let out:Laya.Vector3 = new Laya.Vector3();
        this._map.scenec.camera.convertScreenCoordToOrthographicCoord(this._mainPlayer.transform.position, out);
        let pt:Laya.Point = Laya.Point.TEMP.setTo(out.x, out.y);
        this.mousePt.setTo(Laya.MouseManager.instance.mouseX, Laya.MouseManager.instance.mouseY);

        let speed:number = 8;
        let angle:number = this.GetAngle( pt, this.mousePt )
        // 旋转
        this._a.y = 90 - angle;
        this._mainPlayer.rot(this._a);

        let rad:number = Math.PI / 180 * angle;
        pt.x = Math.cos(rad) * speed;
        pt.y = Math.sin(rad) * speed;

        // pt.x = this._mainPlayer.x + pt.x;
        // pt.x = Math.max(0, Math.min(pt.x, this._map.W));
        //
        // pt.y = this._mainPlayer.y + pt.y;
        // pt.y = Math.max(0, Math.min(pt.y, this._map.H));

        this._mainPlayer.setPosition(pt.x, pt.y);
        this._map.lookTarget(pt.x, pt.y);

        this._mainPlayer.doRun();
    }

    private GetAngle( src :Laya.Point, tar :Laya.Point ):number
    {
        return Math.atan2( tar.y-src.y, tar.x-src.x ) * ( 180/Math.PI );
    }

    private GetRadian( src :Laya.Point, tar :Laya.Point ):number
    {
        return Math.PI / 180 * this.GetAngle( src, tar );
    }

    public get mainPlayer():ScenePlayer{
        return this._mainPlayer;
    }

    public get map():SceneMap{
        return this._map;
    }
}