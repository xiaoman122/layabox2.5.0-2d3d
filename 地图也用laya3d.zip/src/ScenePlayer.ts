import SceneManager from "./SceneManager";
import PlayerStateScript from "./PlayerStateScript";
import MultiplePassOutlineMaterial from "./material/MultiplePassOutlineMaterial";

export default class ScenePlayer extends Laya.Sprite3D
{
    private _d3:Laya.Sprite3D;
    private _animator:Laya.Animator;
    public init():void
    {
        // let s2:Laya.Image = new Laya.Image("res/threeDimen/monkey.png");
        // s2.pos(-110>>1, -145);
        // this.addChild(s2);

        // Laya.Sprite3D.load("res/threeDimen/skinModel/LayaMonkey/LayaMonkey.lh", Laya.Handler.create(this, function(layaMonkey) {
        Laya.Sprite3D.load("res/threeDimen_mine/LayaScene_SampleScene/Conventional/Diana_Skin11.lh", Laya.Handler.create(this, function(layaMonkey) {

            let skinMeshSpr3d:Laya.SkinnedMeshSprite3D = layaMonkey.getChildAt(0).getChildAt(5) as Laya.SkinnedMeshSprite3D;
            let customMaterial = new MultiplePassOutlineMaterial();
            let tex = (skinMeshSpr3d.skinnedMeshRenderer.sharedMaterial as Laya.UnlitMaterial).albedoTexture;
            skinMeshSpr3d.skinnedMeshRenderer.sharedMaterial = customMaterial;

            customMaterial.albedoTexture = tex;

            this.addChild(layaMonkey);
            layaMonkey.transform.localScale = new Laya.Vector3(0.02, 0.02, 0.02);
            this._d3 = layaMonkey;

            let animator:Laya.Animator = layaMonkey.getChildAt(0).getComponent(Laya.Animator);
            this._animator = animator;
            let layer:any = animator.getControllerLayer();
            let states:Array<Laya.AnimatorState> = layer["_states"];
            states.forEach(function (s:Laya.AnimatorState) {
                let script:PlayerStateScript = s.addScript(PlayerStateScript) as PlayerStateScript;
                script.owner = s;
            })
        }));
    }

    public doRun():void{
        if (this._animator){
            this._animator.play("run");
        }
    }

    public doIdle():void{
        this._animator.crossFade("idle1", 0.1);
    }

    public  rot(rot:Laya.Vector3):void{
        this._d3.transform.rotationEuler = rot;
        //this._d3.transform.rotate(rot, true, false);
        console.log("旋转后： x=" + this._d3.transform.rotationEuler.x + " y=" + this._d3.transform.rotationEuler.y + " z="  + this._d3.transform.rotationEuler.z);
    }

    public setPosition(tox:number, toy:number):void{

    }
}