export default class PlayerStateScript extends Laya.AnimatorStateScript {
    public owner:Laya.AnimatorState;
    /**
     * 动画状态开始时执行。
     */
    onStateEnter():void
    {
        console.log("onStateEnter:" + this.owner.name);
    }

    /**
     * 动画状态更新时执行。
     */
    onStateUpdate():void
    {
        console.log("onStateUpdate:" + this.owner.name );
    }

    /**
     * 动画状态退出时执行。
     */
    onStateExit():void
    {
        console.log("onStateExit:" + this.owner.name);
    }
}