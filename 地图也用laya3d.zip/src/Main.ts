import Scene2DPlayer3D from "./Scene2DPlayer3D";

class Main {
    constructor() {
        new Scene2DPlayer3D();
    }
}
//激活启动类
new Main();
