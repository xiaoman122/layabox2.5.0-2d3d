export default class Quad extends Laya.MeshSprite3D
{
    public static createQuad(w:number, h:number):Laya.Mesh{
        let slices:number = 1;
        let stacks:number = 1;
        let long:number = w;
        let width:number = h;

        let vertexCount = (stacks + 1) * (slices + 1);
        let indexCount = stacks * slices * 2 * 3;
        let indices = new Uint16Array(indexCount);
        let vertexDeclaration = Laya.VertexMesh.getVertexDeclaration("POSITION,UV");
        let vertexFloatStride = vertexDeclaration.vertexStride / 4;
        let vertices = new Float32Array(vertexCount * vertexFloatStride);
        let stacksLong = long / stacks;
        let slicesWidth = width / slices;
        let verticeCount = 0;
        for (let i = 0; i <= slices; i++) {
            for (let j = 0; j <= stacks; j++) {
                vertices[verticeCount++] = j * stacksLong;
                vertices[verticeCount++] = -i * slicesWidth;
                vertices[verticeCount++] = 0;
                vertices[verticeCount++] = j * 1 / stacks;
                vertices[verticeCount++] = i * 1 / slices;
            }
        }
        let indiceIndex = 0;
        for (let i = 0; i < slices; i++) {
            for (let j = 0; j < stacks; j++) {
                indices[indiceIndex++] = (i + 1) * (stacks + 1) + j;
                indices[indiceIndex++] = i * (stacks + 1) + j;
                indices[indiceIndex++] = (i + 1) * (stacks + 1) + j + 1;
                indices[indiceIndex++] = i * (stacks + 1) + j;
                indices[indiceIndex++] = i * (stacks + 1) + j + 1;
                indices[indiceIndex++] = (i + 1) * (stacks + 1) + j + 1;
            }
        }

        indices[indiceIndex++] = 2;
        indices[indiceIndex++] = 3;
        indices[indiceIndex++] = 0;
        indices[indiceIndex++] = 0;
        indices[indiceIndex++] = 3;
        indices[indiceIndex++] = 1;

        // indices[indiceIndex++] = 2;
        // indices[indiceIndex++] = 0;
        // indices[indiceIndex++] = 3;
        // indices[indiceIndex++] = 0;
        // indices[indiceIndex++] = 1;
        // indices[indiceIndex++] = 3;
        let ret:Laya.Mesh = (Laya.PrimitiveMesh as any)._createMesh(vertexDeclaration, vertices, indices);
        return ret;
    }
}