import Scene3DContainer from "./Scene3DContainer";
import Quad from "./quad/Quad";

export default class SceneMap{

    private readonly numX:number = 10;
    private readonly numY:number = 10;

    public readonly W:number = this.numX * 256;
    public readonly H:number = this.numY * 256;

    private readonly _scenec:Scene3DContainer;

    private readonly _mapLayer:Laya.Sprite3D;
    private readonly _middle:Laya.Sprite3D;

    private _chunkW:number = 0;
    private _chunkH:number = 0;

    private _offx:number;
    private _offy:number;
    constructor(){

        this._scenec = new Scene3DContainer();
        this._chunkH = this._chunkW = this._scenec.designptu * 256;

        this._mapLayer = new Laya.Sprite3D();
        this._scenec.addChild(this._mapLayer);
        this.load();

        this._middle = new Laya.Sprite3D();
        this._scenec.addChild(this._middle);
    }

    public onResize():void{

        let w:number = Laya.stage.width;
        let h:number = Laya.stage.height;

        let lx:number = Math.max(0, this._offx - (w >> 1));
        let ly:number = Math.max(0, this._offy - (h >> 1));

        let pos = this._scenec.camera.transform.position;
        pos.setValue(lx + this._scenec.camera.viewport.width/2, -ly - this._scenec.camera.viewport.height/2, pos.z);
        this._scenec.camera.transform.position = pos;
    }

    private load():void{
        for (let x:number = 0; x < this.numX; ++x)
        {
            for (let y:number = 0; y < this.numY; ++y)
            {
                let spr:Laya.MeshSprite3D = new Laya.MeshSprite3D(Quad.createQuad());
                let mat:Laya.UnlitMaterial = new Laya.UnlitMaterial();
                Laya.Texture2D.load("res/map/1001/chunks/ml_" + x + "_" + y + ".jpg", Laya.Handler.create(this, function(mat, tex){
                    //纹理加载完成后赋值
                    mat.albedoTexture = tex;
                }, [mat]));
                spr.transform.position = new Laya.Vector3(x*this._chunkW, -y*this._chunkH, 0);
                this._mapLayer.addChild(spr);
            }
        }
    }

    public get scenec():Scene3DContainer{
        return this._scenec;
    }

    public addMiddle(p:Laya.Sprite3D):void{
        this._middle.addChild(p);
    }

    public lookTarget(tox:number, toy:number):void{
        this._offx = tox;
        this._offy = toy;
        this.onResize();
    }
}